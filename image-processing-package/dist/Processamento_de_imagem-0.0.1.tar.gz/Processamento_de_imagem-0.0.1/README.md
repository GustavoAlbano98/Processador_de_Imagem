# CRIAÇÃO DE PACOTES DE PROCESSAMENTO DE IMAGENS

DESCRIÇÃO
O image_processing é usado para:

Em processamento:

- Correspondencia de histograma
- Semelhanca estrutural
- Redimensionar imagem

Util:

- Ler imagem
- Salvar imagem
- Plotar imagem
- Resultado da trama
- Plotar histograma

## Instalação

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing_package

```bash
pip install image_processing_package
```

## Author

João Gustavo Costa

## License

[MIT](https://choosealicense.com/licenses/mit/)
